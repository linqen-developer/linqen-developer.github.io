# Remote File Move

Real PC-to-PC file movement for trusted Windows machines.

Remote File Move is not a Chrome-only trick. The Chrome extension is the control surface, and the native Windows helper performs the OS clipboard/FileDrop work needed for real Ctrl+C -> Ctrl+V file movement.

## What it does

- Watches copied allowed files on one trusted PC.
- Sends the file package through the trusted bridge relay.
- Imports the package on the receiving PC.
- Sets the receiving Windows FileDrop clipboard so normal Ctrl+V works in Explorer.
- Shows status/repair/pause/resume/recent activity in the Chrome popup.
- Offers a Chrome-download fallback for pending ZIP payloads.

## Required pieces

1. Chrome Web Store extension: Remote File Move.
2. Native helper installed once on each Windows PC.

Chrome Web Store extensions cannot install native Windows helpers by themselves. The helper registers the native messaging host:

- `com.openclaw.remote_file_move`

The helper allows both:

- CWS extension ID: `bheeeemfbmphehdchegdgneboadjdjcd`
- local development extension ID generated from `manifest.key`

## Build

```powershell
npm run verify
npm run native:smoke
npm run pack:cws
npm run pack
```

Outputs:

- `dist/remote-file-move-v0.2.1-cws-draft.zip`
- `dist/remote-file-move-v0.2.1.zip`

## Local helper install

```powershell
install-helper.cmd
```

Activation is explicit:

```powershell
node installer/install-oneinstall.mjs --activate --side=office
node installer/install-oneinstall.mjs --activate --side=home
```

Do not activate this helper on Andrea's current office/home setup unless intentionally replacing or testing alongside the existing `OpenClawClipboardBridge`.
