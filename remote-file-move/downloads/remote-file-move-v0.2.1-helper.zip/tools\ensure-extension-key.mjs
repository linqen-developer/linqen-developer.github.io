import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TEMPLATE = path.join(ROOT, 'extension', 'manifest.template.json');
const MANIFEST = path.join(ROOT, 'extension', 'manifest.json');
const KEY_FILE = path.join(ROOT, 'extension', 'extension-key-public.txt');
const ID_FILE = path.join(ROOT, 'extension', 'EXTENSION_ID.txt');

function computeId(publicKeyB64) {
  const der = Buffer.from(publicKeyB64, 'base64');
  const hash = crypto.createHash('sha256').update(der).digest().subarray(0, 16);
  const alphabet = 'abcdefghijklmnop';
  let id = '';
  for (const byte of hash) {
    id += alphabet[byte >> 4] + alphabet[byte & 0x0f];
  }
  return id;
}

async function getOrCreateKey() {
  try {
    const existing = (await fs.readFile(KEY_FILE, 'utf8')).trim();
    if (existing) return existing;
  } catch {}
  const { publicKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'der' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
  });
  const b64 = publicKey.toString('base64');
  await fs.writeFile(KEY_FILE, b64 + '\n', 'utf8');
  return b64;
}

export async function ensureExtensionKey() {
  const publicKeyB64 = await getOrCreateKey();
  const manifest = JSON.parse(await fs.readFile(TEMPLATE, 'utf8'));
  manifest.key = publicKeyB64;
  await fs.writeFile(MANIFEST, JSON.stringify(manifest, null, 2) + '\n', 'utf8');
  const id = computeId(publicKeyB64);
  await fs.writeFile(ID_FILE, id + '\n', 'utf8');
  return { ok: true, extensionId: id, manifest: MANIFEST };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  console.log(JSON.stringify(await ensureExtensionKey(), null, 2));
}
