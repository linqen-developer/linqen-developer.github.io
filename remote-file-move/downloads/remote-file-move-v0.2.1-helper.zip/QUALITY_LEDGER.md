# QUALITY_LEDGER.md - Remote File Move

[VERSION]
current=0.2.1
status=full_native_helper_cws_rebuild_with_helper_install_guidance

[QUALITY_GATES]
manifest_json=required
nativeMessaging=required for real Windows FileDrop clipboard movement
node_syntax=required for extension/native/installer/tools
powershell_parse=required for bridge-agent/import/set-filedrop scripts
native_smoke=required
package_zip=required: CWS extension + helper/source package
cws_allowed_origin=helper must allow `chrome-extension://bheeeemfbmphehdchegdgneboadjdjcd/`
legacy_bridge=do not disrupt %APPDATA%\OpenClawClipboardBridge during packaging

[KNOWN_LIMITS]
chrome_policy=Chrome extension alone cannot install native helper or set Windows FileDrop clipboard.
correct_product_shape=CWS extension + native helper installer; extension detects/controls helper.
review_risk=nativeMessaging requires clear single-purpose and helper-install disclosure.
token_policy=bridge token is local helper data and not packaged in CWS extension.

[VERIFICATION_LOG]
- 2026-05-29 v0.1.1 status-only CWS submission cancelled/not pending because product intent required real movement
- 2026-05-29 v0.2.0 full native helper rebuild: npm run verify PASS 32 checks; native:smoke PASS; pack:cws PASS; pack PASS
- 2026-05-29 CWS upload v0.2.0 PASS; metadata updated for native helper; publish API PASS; state PENDING_REVIEW
