import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';

const APPDATA = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
const APP_DIR = path.join(APPDATA, 'RemoteFileMove');
const STARTUP_CMD = path.join(APPDATA, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'RemoteFileMove.cmd');
const HOST_NAME = 'com.openclaw.remote_file_move';
const removeFiles = process.argv.includes('--remove-files');

function runReg(args) {
  const res = spawnSync('reg.exe', args, { encoding: 'utf8', windowsHide: true });
  if (res.status !== 0 && !(res.stderr || res.stdout || '').includes('ERROR: The system was unable to find')) {
    throw new Error((res.stderr || res.stdout || '').trim() || `reg.exe failed ${args.join(' ')}`);
  }
}

runReg(['delete', `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`, '/f']);
await fs.rm(STARTUP_CMD, { force: true }).catch(() => {});
if (removeFiles) await fs.rm(APP_DIR, { recursive: true, force: true }).catch(() => {});

console.log(JSON.stringify({ ok: true, nativeHostUnregistered: HOST_NAME, startupRemoved: true, appFilesRemoved: removeFiles, appDir: APP_DIR }, null, 2));
