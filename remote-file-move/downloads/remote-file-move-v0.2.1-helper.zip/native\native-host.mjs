import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';

const APP_DIR = path.dirname(fileURLToPath(import.meta.url));
const APPDATA = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
const ONE_APP_DIR = path.join(APPDATA, 'RemoteFileMove');
const LEGACY_APP_DIR = path.join(APPDATA, 'OpenClawClipboardBridge');
const CONFIG_FILE = path.join(ONE_APP_DIR, 'config.json');
const ERR_LOG = path.join(os.homedir(), '.openclaw', 'remote-file-move', 'native-host.err.log');
const DEFAULT_SERVER = 'http://100.82.187.108:18892';
const ALLOWED_EXT = ['.png', '.jpg', '.jpeg', '.pdf', '.zip'];
const MAX_BYTES = 104857600;

function errlog(event, data = {}) {
  try {
    fs.mkdirSync(path.dirname(ERR_LOG), { recursive: true });
    fs.appendFileSync(ERR_LOG, JSON.stringify({ ts: new Date().toISOString(), event, ...data }) + '\n', 'utf8');
  } catch {}
}

function inferSide() {
  const host = os.hostname().toUpperCase();
  if (host.includes('N8CHUVF') || host.includes('OFFICE')) return 'office';
  if (host.includes('6E8V0CP') || host.includes('HOME')) return 'home';
  return 'office';
}

function peerOf(side) {
  return side === 'office' ? 'home' : 'office';
}

async function readJson(file, fallback = null) {
  try { return JSON.parse(await fsp.readFile(file, 'utf8')); } catch { return fallback; }
}

async function writeJson(file, data) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  await fsp.writeFile(file, JSON.stringify(data, null, 2), 'utf8');
}

async function getConfig() {
  const existing = await readJson(CONFIG_FILE, null);
  const side = existing?.side === 'home' || existing?.side === 'office' ? existing.side : inferSide();
  const cfg = {
    side,
    peer: peerOf(side),
    server: existing?.server || process.env.OPENCLAW_CLIPBOARD_BRIDGE_SERVER || DEFAULT_SERVER,
    allowedExtensions: existing?.allowedExtensions || ALLOWED_EXT,
    maxBytes: Number(existing?.maxBytes || MAX_BYTES),
    chromeDownloadMode: existing?.chromeDownloadMode ?? true
  };
  if (!existing) await writeJson(CONFIG_FILE, cfg).catch(() => {});
  return cfg;
}

function dataRoot(side) {
  return path.join(os.homedir(), '.openclaw', 'remote-file-move', side);
}

function legacyDataRoot(side) {
  return path.join(os.homedir(), '.openclaw', 'clipboard-bridge', side);
}

function tokenPath() {
  const own = path.join(ONE_APP_DIR, 'token.txt');
  if (fs.existsSync(own)) return own;
  const legacy = path.join(LEGACY_APP_DIR, 'token.txt');
  if (fs.existsSync(legacy)) return legacy;
  return own;
}

async function ensureToken() {
  const own = path.join(ONE_APP_DIR, 'token.txt');
  const legacy = path.join(LEGACY_APP_DIR, 'token.txt');
  await fsp.mkdir(ONE_APP_DIR, { recursive: true });
  if (fs.existsSync(own)) return (await fsp.readFile(own, 'utf8')).trim();
  if (fs.existsSync(legacy)) {
    const t = (await fsp.readFile(legacy, 'utf8')).trim();
    if (t) {
      await fsp.writeFile(own, t, 'utf8');
      return t;
    }
  }
  const generated = crypto.randomBytes(24).toString('base64url');
  await fsp.writeFile(own, generated, 'utf8');
  return generated;
}

function readToken() {
  try { return fs.readFileSync(tokenPath(), 'utf8').trim(); } catch { return ''; }
}

function headers() {
  const t = readToken();
  return t ? { 'X-Bridge-Token': t } : {};
}

async function httpJson(url, options = {}) {
  const res = await fetch(url, { ...options, headers: { ...(options.headers || {}), ...headers() }, signal: AbortSignal.timeout(options.timeoutMs || 5000) });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { json = { text }; }
  if (!res.ok) throw new Error(json?.error || `HTTP ${res.status}`);
  return json;
}

async function tailJsonLines(file, maxLines = 40) {
  try {
    const text = await fsp.readFile(file, 'utf8');
    const lines = text.trim().split(/\r?\n/).filter(Boolean).slice(-maxLines);
    return lines.map((line) => {
      try { return JSON.parse(line); } catch { return { ts: null, event: 'log', message: line.slice(0, 160) }; }
    });
  } catch { return []; }
}

async function recentActivity(side) {
  const files = [
    path.join(dataRoot(side), `agent-${side}.log`),
    path.join(legacyDataRoot(side), `agent-${side}.log`)
  ];
  const rows = (await Promise.all(files.map((file) => tailJsonLines(file)))).flat();
  return rows
    .filter((row) => row && row.event)
    .sort((a, b) => new Date(b.ts || 0) - new Date(a.ts || 0))
    .slice(0, 8);
}

async function readStatusFile(side) {
  return readJson(path.join(dataRoot(side), 'status.json'), null);
}

async function status() {
  const cfg = await getConfig();
  const root = dataRoot(cfg.side);
  const paused = fs.existsSync(path.join(root, 'paused.flag'));
  const statusFile = await readStatusFile(cfg.side);
  const heartbeatMs = statusFile?.heartbeatAt ? (Date.now() - new Date(statusFile.heartbeatAt).getTime()) : Infinity;
  const agentRunning = heartbeatMs < 15000;
  let relayOk = false;
  let pendingCount = 0;
  let relayError = '';
  try {
    await httpJson(`${cfg.server}/health`, { timeoutMs: 3500 });
    relayOk = true;
    const peek = await httpJson(`${cfg.server}/peek?target=${encodeURIComponent(cfg.side)}`, { timeoutMs: 3500 });
    pendingCount = Number(peek.count || 0);
  } catch (error) {
    relayError = error?.message || String(error);
  }
  const recent = await recentActivity(cfg.side);
  const state = paused ? 'paused' : (relayOk && agentRunning ? 'ready' : 'disconnected');
  const reason = paused ? '사용자가 일시정지했습니다.' : (!agentRunning ? '로컬 helper가 아직 실행 중인지 확인이 필요합니다.' : relayError);
  return {
    ok: true,
    state,
    reason,
    side: cfg.side,
    peer: cfg.peer,
    server: cfg.server,
    relayOk,
    agentRunning,
    pendingCount,
    hasToken: Boolean(readToken()),
    statusFile,
    recent,
    allowedExtensions: cfg.allowedExtensions,
    maxBytesMb: Math.round(cfg.maxBytes / 1024 / 1024),
    appDir: ONE_APP_DIR,
    dataRoot: root
  };
}

function spawnDetached(command, args, cwd = ONE_APP_DIR) {
  const child = spawn(command, args, { detached: true, stdio: 'ignore', windowsHide: true, cwd });
  child.unref();
}

async function ensureStarted() {
  const cfg = await getConfig();
  const root = dataRoot(cfg.side);
  await fsp.mkdir(root, { recursive: true });
  await ensureToken();
  await fsp.rm(path.join(root, 'paused.flag'), { force: true }).catch(() => {});

  if (cfg.side === 'office') {
    const relay = path.join(ONE_APP_DIR, 'bridge-relay.mjs');
    if (fs.existsSync(relay)) spawnDetached('node', [relay], ONE_APP_DIR);
  }

  const agent = path.join(ONE_APP_DIR, 'bridge-agent-v2.ps1');
  if (!fs.existsSync(agent)) throw new Error(`helper script missing: ${agent}`);
  spawnDetached('powershell.exe', [
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Sta', '-File', agent,
    '-Side', cfg.side,
    '-Server', cfg.server,
    '-TokenPath', path.join(ONE_APP_DIR, 'token.txt')
  ], ONE_APP_DIR);

  await new Promise((resolve) => setTimeout(resolve, 850));
  return { ok: true, action: 'ensureStarted', status: await status() };
}

async function pause() {
  const cfg = await getConfig();
  const root = dataRoot(cfg.side);
  await fsp.mkdir(root, { recursive: true });
  await fsp.writeFile(path.join(root, 'paused.flag'), new Date().toISOString(), 'utf8');
  return { ok: true, action: 'pause' };
}

async function resume() {
  const cfg = await getConfig();
  await fsp.rm(path.join(dataRoot(cfg.side), 'paused.flag'), { force: true }).catch(() => {});
  return { ok: true, action: 'resume' };
}

async function openReceived() {
  const cfg = await getConfig();
  const dir = path.join(dataRoot(cfg.side), 'received');
  await fsp.mkdir(dir, { recursive: true });
  spawnDetached('explorer.exe', [dir], dir);
  return { ok: true, action: 'openReceived', dir };
}

async function newestReceivedFiles(side) {
  const received = path.join(dataRoot(side), 'received');
  const dirs = await fsp.readdir(received, { withFileTypes: true }).catch(() => []);
  const candidates = [];
  for (const entry of dirs) {
    if (!entry.isDirectory()) continue;
    const full = path.join(received, entry.name);
    const st = await fsp.stat(full).catch(() => null);
    if (st) candidates.push({ full, mtimeMs: st.mtimeMs });
  }
  candidates.sort((a, b) => b.mtimeMs - a.mtimeMs);
  if (!candidates.length) return [];
  const files = await fsp.readdir(candidates[0].full, { withFileTypes: true }).catch(() => []);
  return files.filter((f) => f.isFile() && f.name !== 'manifest.json').map((f) => path.join(candidates[0].full, f.name));
}

function runPowerShellFile(script, args) {
  const res = spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, ...args], {
    encoding: 'utf8',
    windowsHide: true,
    cwd: ONE_APP_DIR
  });
  if (res.status !== 0) throw new Error((res.stderr || res.stdout || '').trim() || `PowerShell failed: ${script}`);
  const out = (res.stdout || '').trim();
  if (!out) return { ok: true };
  try { return JSON.parse(out); } catch { return { ok: true, output: out }; }
}

async function copyLastReceived() {
  const cfg = await getConfig();
  const files = await newestReceivedFiles(cfg.side);
  if (!files.length) return { ok: false, error: '최근 받은 파일이 없습니다.' };
  const script = path.join(ONE_APP_DIR, 'set-filedrop.ps1');
  const result = runPowerShellFile(script, ['-FilesJson', JSON.stringify(files)]);
  return { ok: true, action: 'copyLastReceived', files: files.length, result };
}

async function pendingDownloadInfo() {
  const cfg = await getConfig();
  const peek = await httpJson(`${cfg.server}/peek?target=${encodeURIComponent(cfg.side)}`, { timeoutMs: 5000 });
  if (!peek.job?.job) return { ok: true, pending: false, count: Number(peek.count || 0) };
  const job = String(peek.job.job);
  const token = readToken();
  return {
    ok: true,
    pending: true,
    count: Number(peek.count || 0),
    side: cfg.side,
    source: job.includes('clip-office') ? 'office' : job.includes('clip-home') ? 'home' : cfg.peer,
    job,
    token,
    url: `${cfg.server}/download?target=${encodeURIComponent(cfg.side)}&job=${encodeURIComponent(job)}`
  };
}

async function importArchive(payload = {}) {
  const cfg = await getConfig();
  const archivePath = String(payload.archivePath || '');
  const job = String(payload.job || path.basename(archivePath, '.zip')).replace(/[^a-zA-Z0-9_.-]/g, '').slice(0, 120);
  if (!archivePath || !fs.existsSync(archivePath)) throw new Error('다운로드 파일을 찾지 못했습니다.');
  const script = path.join(ONE_APP_DIR, 'import-archive.ps1');
  const result = runPowerShellFile(script, ['-Archive', archivePath, '-Side', cfg.side, '-Job', job]);
  await httpJson(`${cfg.server}/ack?target=${encodeURIComponent(cfg.side)}&job=${encodeURIComponent(job)}`, { method: 'POST', timeoutMs: 10000 }).catch((error) => {
    errlog('ack_error', { job, error: error?.message || String(error) });
  });
  return { ok: true, action: 'importArchive', job, files: result.files || 0, result };
}

async function diagnose() {
  const s = await status();
  const summary = s.state === 'ready'
    ? '정상입니다. Ctrl+C 후 반대편에서 Ctrl+V 하시면 됩니다.'
    : `확인 필요: ${s.reason || 'helper/relay 상태를 확인하세요.'}`;
  return { ok: true, action: 'diagnose', summary, status: s };
}

async function logs() {
  const cfg = await getConfig();
  return { ok: true, action: 'logs', recent: await recentActivity(cfg.side) };
}

async function dispatch(message) {
  const action = message?.action;
  if (action === 'status') return status();
  if (action === 'ensureStarted') return ensureStarted();
  if (action === 'pause') return pause();
  if (action === 'resume') return resume();
  if (action === 'openReceived') return openReceived();
  if (action === 'copyLastReceived') return copyLastReceived();
  if (action === 'pendingDownloadInfo') return pendingDownloadInfo();
  if (action === 'importArchive') return importArchive(message.payload || {});
  if (action === 'diagnose') return diagnose();
  if (action === 'logs') return logs();
  return { ok: false, error: `unknown action: ${action}` };
}

function send(obj) {
  const json = Buffer.from(JSON.stringify(obj), 'utf8');
  const header = Buffer.alloc(4);
  header.writeUInt32LE(json.length, 0);
  process.stdout.write(Buffer.concat([header, json]));
}

let input = Buffer.alloc(0);
process.stdin.on('data', (chunk) => {
  input = Buffer.concat([input, chunk]);
  while (input.length >= 4) {
    const len = input.readUInt32LE(0);
    if (input.length < 4 + len) return;
    const body = input.subarray(4, 4 + len);
    input = input.subarray(4 + len);
    Promise.resolve()
      .then(() => JSON.parse(body.toString('utf8')))
      .then(async (msg) => {
        const result = await dispatch(msg);
        send({ requestId: msg.requestId, ...result });
      })
      .catch((error) => {
        errlog('request_error', { error: error?.message || String(error), stack: error?.stack });
        send({ ok: false, error: error?.message || String(error) });
      });
  }
});

process.stdin.on('end', () => setTimeout(() => process.exit(0), 250));
process.on('uncaughtException', (error) => {
  errlog('uncaughtException', { error: error?.message || String(error), stack: error?.stack });
  send({ ok: false, error: error?.message || String(error) });
  process.exit(1);
});
