@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Remote File Move requires Node.js 20 or newer for this helper build.
  echo Install Node.js, then run this file again.
  pause
  exit /b 1
)
node installer\install-oneinstall.mjs --activate %*
if errorlevel 1 (
  echo.
  echo Remote File Move helper installation failed.
  pause
  exit /b 1
)
echo.
echo Remote File Move helper installed and activated.
echo Install the Chrome Web Store extension on this PC, then open the popup to confirm Ready.
pause
