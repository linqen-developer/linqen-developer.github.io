param(
  [Parameter(Mandatory=$true)][string]$SourceDir,
  [Parameter(Mandatory=$true)][string]$OutFile
)

$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $OutFile) { Remove-Item -LiteralPath $OutFile -Force }
Compress-Archive -Path (Join-Path $SourceDir '*') -DestinationPath $OutFile -Force
@{ ok = $true; outFile = $OutFile } | ConvertTo-Json -Compress
