import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const child = spawn('node', [path.join(ROOT, 'native', 'native-host.mjs')], { cwd: ROOT, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });

const msg = Buffer.from(JSON.stringify({ requestId: 'smoke-1', action: 'status' }), 'utf8');
const header = Buffer.alloc(4);
header.writeUInt32LE(msg.length, 0);
child.stdin.write(Buffer.concat([header, msg]));
child.stdin.end();

let buf = Buffer.alloc(0);
let err = '';
child.stderr.on('data', (d) => { err += d.toString(); });
child.stdout.on('data', (chunk) => { buf = Buffer.concat([buf, chunk]); });
const result = await new Promise((resolve) => {
  const timer = setTimeout(() => resolve({ ok: false, error: 'timeout' }), 8000);
  child.on('close', () => {
    clearTimeout(timer);
    if (buf.length < 4) return resolve({ ok: false, error: 'no response', stderr: err.trim() });
    const len = buf.readUInt32LE(0);
    const body = buf.subarray(4, 4 + len).toString('utf8');
    try { resolve(JSON.parse(body)); } catch (e) { resolve({ ok: false, error: e.message, body, stderr: err.trim() }); }
  });
});
if (!result.ok) {
  console.error(JSON.stringify(result, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({ ok: true, state: result.state, side: result.side, relayOk: result.relayOk, agentRunning: result.agentRunning }, null, 2));
