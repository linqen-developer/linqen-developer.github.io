param(
  [Parameter(Mandatory=$true)][string]$Archive,
  [ValidateSet('office','home')][string]$Side = 'office',
  [string]$Job = ''
)

$ErrorActionPreference = 'Stop'
$AllowedExt = @('.png', '.jpg', '.jpeg', '.pdf', '.zip')
$DataRoot = Join-Path $env:USERPROFILE ".openclaw\remote-file-move\$Side"
$ReceivedRoot = Join-Path $DataRoot 'received'
$LogFile = Join-Path $DataRoot "agent-$Side.log"
if (-not $Job) { $Job = [System.IO.Path]::GetFileNameWithoutExtension($Archive) }
$Job = ($Job -replace '[^a-zA-Z0-9_.-]', '').Substring(0, [Math]::Min(120, ($Job -replace '[^a-zA-Z0-9_.-]', '').Length))
if (-not $Job) { $Job = "chrome-$((Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssfffZ'))" }
$Extract = Join-Path $ReceivedRoot $Job

function Write-BridgeLog {
  param([string]$Event, [hashtable]$Data = @{})
  try {
    New-Item -ItemType Directory -Force -Path (Split-Path $LogFile -Parent) | Out-Null
    $row = [ordered]@{ ts = (Get-Date).ToString('o'); side = $Side; event = $Event }
    foreach ($k in $Data.Keys) { $row[$k] = $Data[$k] }
    ($row | ConvertTo-Json -Compress -Depth 5) | Add-Content -Path $LogFile -Encoding UTF8
  } catch {}
}

try {
  if (-not (Test-Path -LiteralPath $Archive -PathType Leaf)) { throw "Archive not found: $Archive" }
  if (Test-Path $Extract) { Remove-Item -LiteralPath $Extract -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $Extract | Out-Null
  Expand-Archive -Path $Archive -DestinationPath $Extract -Force
  $files = @(Get-ChildItem -LiteralPath $Extract -File | Where-Object { $_.Name -ne 'manifest.json' -and ($AllowedExt -contains $_.Extension.ToLowerInvariant()) } | Select-Object -ExpandProperty FullName)
  if ($files.Count -lt 1) { throw 'No supported files were found in the downloaded archive.' }

  Add-Type -AssemblyName System.Windows.Forms
  $sc = New-Object System.Collections.Specialized.StringCollection
  foreach ($f in $files) { [void]$sc.Add($f) }
  [System.Windows.Forms.Clipboard]::SetFileDropList($sc)
  Write-BridgeLog 'imported_archive' @{ job = $Job; files = $files.Count; archive = $Archive }
  Write-BridgeLog 'clipboard_set' @{ files = $files.Count; first = $files[0] }
  @{ ok = $true; job = $Job; files = $files.Count; extract = $Extract; first = $files[0] } | ConvertTo-Json -Compress
} catch {
  Write-BridgeLog 'import_archive_error' @{ job = $Job; error = $_.Exception.Message }
  @{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress
  exit 1
}
