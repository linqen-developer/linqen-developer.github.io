import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { ensureExtensionKey } from './ensure-extension-key.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(await fs.readFile(path.join(ROOT, 'package.json'), 'utf8'));
const name = `${pkg.name}-v${pkg.version}`;
const dist = path.join(ROOT, 'dist');
const stageRoot = path.join(dist, '_stage');
const stage = path.join(stageRoot, name);
const outFile = path.join(dist, `${name}.zip`);

await ensureExtensionKey();
await fs.rm(stageRoot, { recursive: true, force: true });
await fs.mkdir(stage, { recursive: true });

async function copy(item) {
  const src = path.join(ROOT, item);
  const dst = path.join(stage, item);
  const st = await fs.stat(src);
  if (st.isDirectory()) await fs.cp(src, dst, { recursive: true });
  else {
    await fs.mkdir(path.dirname(dst), { recursive: true });
    await fs.copyFile(src, dst);
  }
}

for (const item of [
  'package.json',
  'install-helper.cmd',
  'README.md',
  'PROJECT_CONTRACT.md',
  'DESIGN_CONTRACT.md',
  'QUALITY_LEDGER.md',
  'extension',
  'native',
  'installer',
  'tools'
]) {
  await copy(item);
}

await fs.mkdir(dist, { recursive: true });
const res = spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(ROOT, 'tools', 'compress-archive.ps1'), stage, outFile], {
  cwd: ROOT,
  encoding: 'utf8',
  windowsHide: true
});
if (res.status !== 0) throw new Error((res.stderr || res.stdout || '').trim() || 'archive compression failed');
const st = await fs.stat(outFile);
await fs.rm(stageRoot, { recursive: true, force: true });
console.log(JSON.stringify({ ok: true, package: outFile, bytes: st.size }, null, 2));
