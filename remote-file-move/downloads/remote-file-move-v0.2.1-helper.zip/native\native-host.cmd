@echo off
setlocal
set "APP_DIR=%APPDATA%\RemoteFileMove"
set "LOG_DIR=%USERPROFILE%\.openclaw\remote-file-move"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>nul
if exist "%APP_DIR%\native-host.mjs" (
  node "%APP_DIR%\native-host.mjs" 2>> "%LOG_DIR%\native-host.err.log"
) else (
  node "%~dp0native-host.mjs" 2>> "%LOG_DIR%\native-host.err.log"
)
