import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';
import { ensureExtensionKey } from '../tools/ensure-extension-key.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const APPDATA = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
const APP_DIR = path.join(APPDATA, 'RemoteFileMove');
const LEGACY_DIR = path.join(APPDATA, 'OpenClawClipboardBridge');
const STARTUP_DIR = path.join(APPDATA, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
const HOST_NAME = 'com.openclaw.remote_file_move';
const CWS_EXTENSION_ID = 'bheeeemfbmphehdchegdgneboadjdjcd';
const SERVER_DEFAULT = 'http://100.82.187.108:18892';

const args = new Set(process.argv.slice(2));
const activate = args.has('--activate');
const sideArg = process.argv.find(a => a.startsWith('--side='))?.split('=')[1];
const serverArg = process.argv.find(a => a.startsWith('--server='))?.slice('--server='.length);

function inferSide() {
  const host = os.hostname().toUpperCase();
  if (host.includes('N8CHUVF') || host.includes('OFFICE')) return 'office';
  if (host.includes('6E8V0CP') || host.includes('HOME')) return 'home';
  return 'office';
}

function computeId(publicKeyB64) {
  const der = Buffer.from(publicKeyB64, 'base64');
  const hash = crypto.createHash('sha256').update(der).digest().subarray(0, 16);
  const alphabet = 'abcdefghijklmnop';
  let id = '';
  for (const byte of hash) id += alphabet[byte >> 4] + alphabet[byte & 0x0f];
  return id;
}

async function copyDir(src, dst) {
  await fsp.mkdir(dst, { recursive: true });
  const entries = await fsp.readdir(src, { withFileTypes: true });
  for (const entry of entries) {
    const from = path.join(src, entry.name);
    const to = path.join(dst, entry.name);
    if (entry.isDirectory()) await copyDir(from, to);
    else if (entry.isFile()) await fsp.copyFile(from, to);
  }
}

async function ensureToken() {
  const own = path.join(APP_DIR, 'token.txt');
  const legacy = path.join(LEGACY_DIR, 'token.txt');
  if (fs.existsSync(own)) return 'existing';
  if (fs.existsSync(legacy)) {
    await fsp.copyFile(legacy, own);
    return 'copied-legacy';
  }
  await fsp.writeFile(own, crypto.randomBytes(24).toString('base64url'), 'utf8');
  return 'generated';
}

function runReg(args) {
  const res = spawnSync('reg.exe', args, { encoding: 'utf8', windowsHide: true });
  if (res.status !== 0) throw new Error((res.stderr || res.stdout || '').trim() || `reg.exe failed ${args.join(' ')}`);
}

function spawnDetached(command, args, cwd = APP_DIR) {
  const child = spawn(command, args, { detached: true, stdio: 'ignore', windowsHide: true, cwd });
  child.unref();
}

await ensureExtensionKey();
await fsp.mkdir(APP_DIR, { recursive: true });
await fsp.mkdir(STARTUP_DIR, { recursive: true });

const sourceNative = path.join(ROOT, 'native');
const sourceExtension = path.join(ROOT, 'extension');
await copyDir(sourceNative, APP_DIR);
await copyDir(sourceExtension, path.join(APP_DIR, 'extension'));

const manifest = JSON.parse(await fsp.readFile(path.join(ROOT, 'extension', 'manifest.json'), 'utf8'));
const extensionId = computeId(manifest.key);
const hostManifestPath = path.join(APP_DIR, `${HOST_NAME}.json`);
const allowedOrigins = Array.from(new Set([
  `chrome-extension://${CWS_EXTENSION_ID}/`,
  `chrome-extension://${extensionId}/`
]));
const hostManifest = {
  name: HOST_NAME,
  description: 'Remote File Move native helper',
  path: path.join(APP_DIR, 'native-host.cmd'),
  type: 'stdio',
  allowed_origins: allowedOrigins
};
await fsp.writeFile(hostManifestPath, JSON.stringify(hostManifest, null, 2) + '\n', 'utf8');

runReg(['add', `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`, '/ve', '/t', 'REG_SZ', '/d', hostManifestPath, '/f']);

const side = sideArg === 'home' || sideArg === 'office' ? sideArg : inferSide();
const peer = side === 'office' ? 'home' : 'office';
const server = serverArg || process.env.OPENCLAW_CLIPBOARD_BRIDGE_SERVER || SERVER_DEFAULT;
const config = {
  side,
  peer,
  server,
  allowedExtensions: ['.png', '.jpg', '.jpeg', '.pdf', '.zip'],
  maxBytes: 104857600,
  chromeDownloadMode: true,
  installedAt: new Date().toISOString(),
  extensionId,
  cwsExtensionId: CWS_EXTENSION_ID,
  allowedOrigins
};
await fsp.writeFile(path.join(APP_DIR, 'config.json'), JSON.stringify(config, null, 2) + '\n', 'utf8');
const tokenState = await ensureToken();

const startupCmd = `@echo off\r\ncd /d "%APPDATA%\\RemoteFileMove"\r\nif /I "${side}"=="office" start "Remote File Move Relay" /min node "%APPDATA%\\RemoteFileMove\\bridge-relay.mjs"\r\nstart "Remote File Move Agent (${side})" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -Sta -File "%APPDATA%\\RemoteFileMove\\bridge-agent-v2.ps1" -Side ${side} -Server ${server} -TokenPath "%APPDATA%\\RemoteFileMove\\token.txt"\r\n`;
await fsp.writeFile(path.join(APP_DIR, 'start-bridge.cmd'), startupCmd, 'utf8');

if (activate) {
  await fsp.writeFile(path.join(STARTUP_DIR, 'RemoteFileMove.cmd'), startupCmd, 'utf8');
  if (side === 'office') spawnDetached('node', [path.join(APP_DIR, 'bridge-relay.mjs')]);
  spawnDetached('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Sta', '-File', path.join(APP_DIR, 'bridge-agent-v2.ps1'), '-Side', side, '-Server', server, '-TokenPath', path.join(APP_DIR, 'token.txt')]);
}

console.log(JSON.stringify({
  ok: true,
  appDir: APP_DIR,
  extensionDir: path.join(APP_DIR, 'extension'),
  sourceExtensionDir: path.join(ROOT, 'extension'),
  extensionId,
  cwsExtensionId: CWS_EXTENSION_ID,
  allowedOrigins,
  nativeHost: HOST_NAME,
  hostManifestPath,
  registryKey: `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`,
  side,
  peer,
  server,
  token: tokenState,
  activated: activate,
  next: [
    'Open chrome://extensions',
    'Enable Developer mode for internal unpacked install',
    `Load unpacked: ${path.join(APP_DIR, 'extension')}`
  ]
}, null, 2));
