param(
  [ValidateSet('office','home')][string]$Side = 'office',
  [string]$Server = 'http://100.82.187.108:18892',
  [string]$TokenPath = "$PSScriptRoot\token.txt",
  [int]$PollMs = 700,
  [int64]$MaxBytes = 104857600
)

$ErrorActionPreference = 'Stop'
$Peer = if ($Side -eq 'office') { 'home' } else { 'office' }
$AppRoot = $PSScriptRoot
$DataRoot = Join-Path $env:USERPROFILE ".openclaw\remote-file-move\$Side"
$StageRoot = Join-Path $DataRoot 'stage'
$ReceivedRoot = Join-Path $DataRoot 'received'
$DownloadRoot = Join-Path $DataRoot 'downloads'
$LogFile = Join-Path $DataRoot "agent-$Side.log"
$StatusFile = Join-Path $DataRoot 'status.json'
$PausedFlag = Join-Path $DataRoot 'paused.flag'
$AllowedExt = @('.png', '.jpg', '.jpeg', '.pdf', '.zip')
$script:LastEvent = 'starting'
$script:LastJob = ''
$script:LastPausedState = $false

New-Item -ItemType Directory -Force -Path $DataRoot, $StageRoot, $ReceivedRoot, $DownloadRoot | Out-Null

$createdMutex = $false
$mutex = New-Object System.Threading.Mutex($true, "RemoteFileMove-$Side", [ref]$createdMutex)
if (-not $createdMutex) { exit 0 }

Add-Type -AssemblyName System.Windows.Forms
Add-Type @'
using System.Runtime.InteropServices;
public static class ClipboardBridgeSeq {
  [DllImport("user32.dll")] public static extern uint GetClipboardSequenceNumber();
}
'@

function Write-BridgeLog {
  param([string]$Event, [hashtable]$Data = @{})
  try {
    $script:LastEvent = $Event
    if ($Data.ContainsKey('job')) { $script:LastJob = [string]$Data['job'] }
    $row = [ordered]@{ ts = (Get-Date).ToString('o'); side = $Side; event = $Event }
    foreach ($k in $Data.Keys) { $row[$k] = $Data[$k] }
    ($row | ConvertTo-Json -Compress -Depth 5) | Add-Content -Path $LogFile -Encoding UTF8
  } catch {}
}

function Write-Status {
  param([bool]$Paused = $false)
  try {
    $status = [ordered]@{
      ok = $true
      side = $Side
      peer = $Peer
      pid = $PID
      server = $Server
      paused = $Paused
      heartbeatAt = (Get-Date).ToString('o')
      lastEvent = $script:LastEvent
      lastJob = $script:LastJob
      allowedExtensions = $AllowedExt
      maxBytes = $MaxBytes
    }
    ($status | ConvertTo-Json -Depth 5) | Set-Content -Path $StatusFile -Encoding UTF8
  } catch {}
}

function Get-Token {
  try { return (Get-Content -Path $TokenPath -Raw -ErrorAction Stop).Trim() } catch { return '' }
}

function Get-Headers {
  $t = Get-Token
  if ($t) { return @{ 'X-Bridge-Token' = $t } }
  return @{}
}

function Get-ClipboardSeq {
  try { return [ClipboardBridgeSeq]::GetClipboardSequenceNumber() } catch { return 0 }
}

function Read-ClipboardFiles {
  try {
    if (-not [System.Windows.Forms.Clipboard]::ContainsFileDropList()) { return @() }
    $drop = [System.Windows.Forms.Clipboard]::GetFileDropList()
    $items = @()
    foreach ($item in $drop) {
      if ($item) { $items += [string]$item }
    }
    return $items
  } catch {
    Write-BridgeLog 'clipboard_read_error' @{ error = $_.Exception.Message }
    return @()
  }
}

function Test-UnderPath {
  param([string]$PathValue, [string]$RootValue)
  try {
    $p = [System.IO.Path]::GetFullPath($PathValue).TrimEnd('\')
    $r = [System.IO.Path]::GetFullPath($RootValue).TrimEnd('\')
    return $p.StartsWith($r, [System.StringComparison]::OrdinalIgnoreCase)
  } catch { return $false }
}

function Get-SafeName {
  param([string]$Name, [hashtable]$Used)
  $base = [System.IO.Path]::GetFileNameWithoutExtension($Name) -replace '[\/:*?"<>|]', '_'
  $ext = ([System.IO.Path]::GetExtension($Name)).ToLowerInvariant()
  if (-not $base) { $base = 'file' }
  $candidate = "$base$ext"
  $i = 2
  while ($Used.ContainsKey($candidate.ToLowerInvariant())) {
    $candidate = "$base-$i$ext"
    $i++
  }
  $Used[$candidate.ToLowerInvariant()] = $true
  return $candidate
}

function Send-Files {
  param([string[]]$Files)
  $valid = @()
  $total = [int64]0
  foreach ($f in $Files) {
    if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { continue }
    if (Test-UnderPath $f $DataRoot) { continue }
    if (Test-UnderPath $f $AppRoot) { continue }
    $ext = ([System.IO.Path]::GetExtension($f)).ToLowerInvariant()
    if ($AllowedExt -notcontains $ext) {
      Write-BridgeLog 'skip_extension' @{ path = $f; ext = $ext }
      continue
    }
    $info = Get-Item -LiteralPath $f
    $total += [int64]$info.Length
    $valid += $f
  }
  if ($valid.Count -eq 0) { return }
  if ($total -gt $MaxBytes) {
    Write-BridgeLog 'skip_too_large' @{ count = $valid.Count; bytes = $total; maxBytes = $MaxBytes }
    return
  }

  $job = "clip-$Side-$((Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssfffZ'))-$([guid]::NewGuid().ToString('N').Substring(0,8))"
  $stage = Join-Path $StageRoot $job
  $zip = Join-Path $StageRoot "$job.zip"
  New-Item -ItemType Directory -Force -Path $stage | Out-Null
  $used = @{}
  try {
    foreach ($f in $valid) {
      $name = Get-SafeName ([System.IO.Path]::GetFileName($f)) $used
      Copy-Item -LiteralPath $f -Destination (Join-Path $stage $name) -Force
    }
    $manifest = [ordered]@{
      source = $Side
      target = $Peer
      createdAt = (Get-Date).ToString('o')
      totalBytes = $total
      files = @($valid | ForEach-Object { [System.IO.Path]::GetFileName($_) })
    }
    ($manifest | ConvertTo-Json -Depth 4) | Set-Content -Path (Join-Path $stage 'manifest.json') -Encoding UTF8
    if (Test-Path $zip) { Remove-Item -LiteralPath $zip -Force }
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -Force
    $uri = "$Server/upload?source=$Side&target=$Peer&job=$([uri]::EscapeDataString($job))"
    Invoke-WebRequest -Uri $uri -Method Post -Headers (Get-Headers) -InFile $zip -ContentType 'application/zip' -UseBasicParsing -TimeoutSec 180 | Out-Null
    Write-BridgeLog 'sent' @{ job = $job; target = $Peer; files = $valid.Count; bytes = $total }
  } catch {
    Write-BridgeLog 'send_error' @{ job = $job; error = $_.Exception.Message }
  } finally {
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
  }
}

function Set-ClipboardFiles {
  param([string[]]$Files)
  try {
    $sc = New-Object System.Collections.Specialized.StringCollection
    foreach ($f in $Files) { [void]$sc.Add($f) }
    [System.Windows.Forms.Clipboard]::SetFileDropList($sc)
    Write-BridgeLog 'clipboard_set' @{ files = $Files.Count; first = $Files[0] }
    return $true
  } catch {
    Write-BridgeLog 'clipboard_set_error' @{ error = $_.Exception.Message }
    return $false
  }
}

function Receive-One {
  try {
    $peek = Invoke-RestMethod -Uri "$Server/peek?target=$Side" -Headers (Get-Headers) -TimeoutSec 8
    if (-not $peek.job) { return }
    $job = [string]$peek.job.job
    if (-not $job) { return }
    $zip = Join-Path $DownloadRoot "$job.zip"
    $extract = Join-Path $ReceivedRoot $job
    Invoke-WebRequest -Uri "$Server/download?target=$Side&job=$([uri]::EscapeDataString($job))" -Headers (Get-Headers) -OutFile $zip -UseBasicParsing -TimeoutSec 180
    if (Test-Path $extract) { Remove-Item -LiteralPath $extract -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $extract | Out-Null
    Expand-Archive -Path $zip -DestinationPath $extract -Force
    $files = @(Get-ChildItem -LiteralPath $extract -File | Where-Object { $_.Name -ne 'manifest.json' -and ($AllowedExt -contains $_.Extension.ToLowerInvariant()) } | Select-Object -ExpandProperty FullName)
    if ($files.Count -gt 0 -and (Set-ClipboardFiles $files)) {
      Invoke-WebRequest -Uri "$Server/ack?target=$Side&job=$([uri]::EscapeDataString($job))" -Method Post -Headers (Get-Headers) -UseBasicParsing -TimeoutSec 20 | Out-Null
      Write-BridgeLog 'received' @{ job = $job; files = $files.Count; source = $Peer }
    }
    Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
  } catch {
    Write-BridgeLog 'receive_error' @{ error = $_.Exception.Message }
  }
}

Write-BridgeLog 'started' @{ peer = $Peer; server = $Server; maxBytes = $MaxBytes; allowed = ($AllowedExt -join ',') }
$lastSeq = Get-ClipboardSeq

while ($true) {
  try {
    $paused = Test-Path -LiteralPath $PausedFlag
    if ($paused -ne $script:LastPausedState) {
      $script:LastPausedState = $paused
      if ($paused) { Write-BridgeLog 'paused' @{} } else { Write-BridgeLog 'resumed' @{} }
    }
    Write-Status -Paused:$paused
    if (-not $paused) {
      $seq = Get-ClipboardSeq
      if ($seq -ne $lastSeq) {
        $lastSeq = $seq
        $files = @(Read-ClipboardFiles)
        if ($files.Count -gt 0) { Send-Files $files }
      }
      Receive-One
    }
  } catch {
    Write-BridgeLog 'loop_error' @{ error = $_.Exception.Message }
  }
  Start-Sleep -Milliseconds $PollMs
}
