# DESIGN_CONTRACT.md - Remote File Move

[INTENT]
interface=compact Chrome popup, not a marketing page
feeling=quiet utility; stable; clear status first
primary_action=Keep bridge ready / repair when not ready

[GRID]
popup_width=380px
outer_padding=16px
stack_gap=12px
status_card=full width, 2-column state/detail rhythm
controls=2-column grid for secondary actions; primary action full width
log_rows=recent activity with fixed-height rows and clear event badges

[TOKENS]
background=#F8F9F6
surface=#FFFFFF
surface_alt=#F2EFE8
ink=#2B0F3A
muted=#6E6274
primary=#402048
primary_soft=#D8CBDD
success=#2F7D57
warning=#A86A12
danger=#A94747
border=rgba(43,15,58,0.14)
radius=16px

[CONTENT]
copy_style=short Korean utility labels
avoid=explaining implementation in the popup
show=Ready/Paused/Disconnected, side, peer, last received, queue count, allowed types

[STATES]
ready=green dot + '준비됨'
paused=amber dot + '일시정지'
disconnected=red dot + '연결 필요'
loading=subtle skeleton/status shimmer not required for v1; use busy labels
empty=recent activity empty row
error=concise reason + repair button

[ACCESSIBILITY]
buttons=minimum 40px height
contrast=dark plum text on off-white
motion=minimal; no distracting animations
