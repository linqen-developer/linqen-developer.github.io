import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { ensureExtensionKey } from './ensure-extension-key.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const checks = [];

function run(command, args, label) {
  const res = spawnSync(command, args, { cwd: ROOT, encoding: 'utf8', windowsHide: true });
  checks.push({ label, command: [command, ...args].join(' '), status: res.status, stdout: (res.stdout || '').trim(), stderr: (res.stderr || '').trim() });
  if (res.status !== 0) throw new Error(`${label} failed\n${res.stdout}\n${res.stderr}`);
}

async function assertFile(file, label = file) {
  const st = await fs.stat(path.join(ROOT, file)).catch(() => null);
  if (!st?.isFile()) throw new Error(`Missing ${label}: ${file}`);
  checks.push({ label: `exists ${label}`, status: 0 });
}

const key = await ensureExtensionKey();
checks.push({ label: 'extension key', status: 0, extensionId: key.extensionId });

const files = [
  'extension/manifest.json',
  'extension/background.js',
  'extension/popup.js',
  'extension/popup.html',
  'extension/popup.css',
  'extension/icons/icon128.png',
  'install-helper.cmd',
  'native/native-host.mjs',
  'native/bridge-relay.mjs',
  'native/bridge-agent-v2.ps1',
  'native/import-archive.ps1',
  'native/set-filedrop.ps1',
  'native/native-host.cmd',
  'installer/install-oneinstall.mjs',
  'installer/uninstall-oneinstall.mjs',
  'PROJECT_CONTRACT.md',
  'DESIGN_CONTRACT.md',
  'QUALITY_LEDGER.md',
  'README.md'
];
for (const file of files) await assertFile(file);

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'extension', 'manifest.json'), 'utf8'));
if (manifest.manifest_version !== 3) throw new Error('manifest_version must be 3');
if (!manifest.permissions.includes('nativeMessaging')) throw new Error('nativeMessaging permission missing');
if (!manifest.permissions.includes('downloads')) throw new Error('downloads permission missing');
if (manifest.optional_host_permissions?.length) throw new Error('optional broad host permissions must not be present');
for (const pattern of manifest.host_permissions || []) {
  if (pattern.includes(':*')) throw new Error(`invalid CWS host permission wildcard port: ${pattern}`);
}
checks.push({ label: 'manifest static check', status: 0, permissions: manifest.permissions, host_permissions: manifest.host_permissions });

const installerText = await fs.readFile(path.join(ROOT, 'installer', 'install-oneinstall.mjs'), 'utf8');
if (!installerText.includes('bheeeemfbmphehdchegdgneboadjdjcd')) throw new Error('installer must allow CWS item ID');
checks.push({ label: 'installer CWS allowed origin', status: 0, cwsItemId: 'bheeeemfbmphehdchegdgneboadjdjcd' });

for (const file of [
  'extension/background.js',
  'extension/popup.js',
  'native/native-host.mjs',
  'native/bridge-relay.mjs',
  'installer/install-oneinstall.mjs',
  'installer/uninstall-oneinstall.mjs',
  'tools/ensure-extension-key.mjs',
  'tools/pack.mjs',
  'tools/pack-cws-draft.mjs',
  'tools/native-smoke.mjs'
]) {
  run('node', ['--check', file], `node syntax ${file}`);
}

run('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(ROOT, 'tools', 'check-powershell-parse.ps1'),
  path.join(ROOT, 'native', 'bridge-agent-v2.ps1'),
  path.join(ROOT, 'native', 'import-archive.ps1'),
  path.join(ROOT, 'native', 'set-filedrop.ps1')
], 'powershell parse');

await fs.mkdir(path.join(ROOT, 'qa'), { recursive: true });
await fs.writeFile(path.join(ROOT, 'qa', 'verify-result.json'), JSON.stringify({ ok: true, checkedAt: new Date().toISOString(), checks }, null, 2) + '\n', 'utf8');
console.log(JSON.stringify({ ok: true, extensionId: key.extensionId, cwsItemId: 'bheeeemfbmphehdchegdgneboadjdjcd', checks: checks.length, result: path.join(ROOT, 'qa', 'verify-result.json') }, null, 2));
