param(
  [Parameter(Mandatory=$true)][string]$FilesJson
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

try {
  $files = @($FilesJson | ConvertFrom-Json)
  $sc = New-Object System.Collections.Specialized.StringCollection
  foreach ($f in $files) {
    if ($f -and (Test-Path -LiteralPath ([string]$f) -PathType Leaf)) {
      [void]$sc.Add([string]$f)
    }
  }
  if ($sc.Count -lt 1) { throw 'No valid files to place on clipboard.' }
  [System.Windows.Forms.Clipboard]::SetFileDropList($sc)
  @{ ok = $true; files = $sc.Count; first = $sc[0] } | ConvertTo-Json -Compress
} catch {
  @{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress
  exit 1
}
