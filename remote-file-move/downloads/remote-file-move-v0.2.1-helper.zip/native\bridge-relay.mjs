import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { pipeline } from 'node:stream/promises';

const APP_DIR = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(os.homedir(), '.openclaw', 'remote-file-move', 'relay');
const QUEUE_DIR = path.join(DATA_DIR, 'queues');
const ARCHIVE_DIR = path.join(DATA_DIR, 'archive');
const LOG_FILE = path.join(DATA_DIR, 'relay.log');
const TOKEN_FILE = path.join(APP_DIR, 'token.txt');
const PORT = Number(process.env.OPENCLAW_CLIPBOARD_BRIDGE_PORT || 18892);
const MAX_BYTES = Number(process.env.OPENCLAW_CLIPBOARD_BRIDGE_MAX_BYTES || 105 * 1024 * 1024);
const SIDES = new Set(['office', 'home']);

await fsp.mkdir(QUEUE_DIR, { recursive: true });
await fsp.mkdir(ARCHIVE_DIR, { recursive: true });
for (const side of SIDES) await fsp.mkdir(path.join(QUEUE_DIR, side), { recursive: true });

function token() {
  try { return fs.readFileSync(TOKEN_FILE, 'utf8').trim(); } catch { return ''; }
}

function log(event, data = {}) {
  const row = { ts: new Date().toISOString(), event, ...data };
  const line = JSON.stringify(row);
  console.log(line);
  fs.appendFileSync(LOG_FILE, line + '\n', 'utf8');
}

function sendJson(res, status, obj) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': body.length });
  res.end(body);
}

function auth(req, res) {
  const expected = token();
  if (!expected) return true;
  if (req.headers['x-bridge-token'] === expected) return true;
  sendJson(res, 401, { ok: false, error: 'unauthorized' });
  return false;
}

function safeJob(raw) {
  const value = String(raw || '').replace(/[^a-zA-Z0-9_.-]/g, '').slice(0, 120);
  return value || `job-${Date.now()}`;
}

async function listJobs(side) {
  const dir = path.join(QUEUE_DIR, side);
  const names = (await fsp.readdir(dir).catch(() => [])).filter(n => n.endsWith('.zip')).sort();
  const jobs = [];
  for (const name of names) {
    const full = path.join(dir, name);
    const st = await fsp.stat(full).catch(() => null);
    if (st?.isFile()) jobs.push({ job: name.replace(/\.zip$/, ''), file: name, size: st.size, mtimeMs: st.mtimeMs });
  }
  jobs.sort((a, b) => a.mtimeMs - b.mtimeMs);
  return jobs;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (req.method === 'GET' && url.pathname === '/health') {
      return sendJson(res, 200, { ok: true, service: 'remote-file-move-relay', port: PORT, maxBytes: MAX_BYTES });
    }

    if (!auth(req, res)) return;

    if (req.method === 'GET' && url.pathname === '/peek') {
      const target = url.searchParams.get('target');
      if (!SIDES.has(target)) return sendJson(res, 400, { ok: false, error: 'bad target' });
      const jobs = await listJobs(target);
      return sendJson(res, 200, { ok: true, job: jobs[0] || null, count: jobs.length });
    }

    if (req.method === 'GET' && url.pathname === '/download') {
      const target = url.searchParams.get('target');
      const job = safeJob(url.searchParams.get('job'));
      if (!SIDES.has(target)) return sendJson(res, 400, { ok: false, error: 'bad target' });
      const file = path.join(QUEUE_DIR, target, `${job}.zip`);
      const st = await fsp.stat(file).catch(() => null);
      if (!st?.isFile()) return sendJson(res, 404, { ok: false, error: 'missing job' });
      res.writeHead(200, {
        'content-type': 'application/zip',
        'content-length': st.size,
        'x-bridge-job': job,
        'content-disposition': `attachment; filename="${job}.zip"`
      });
      log('download', { target, job, size: st.size });
      return fs.createReadStream(file).pipe(res);
    }

    if (req.method === 'POST' && url.pathname === '/ack') {
      const target = url.searchParams.get('target');
      const job = safeJob(url.searchParams.get('job'));
      if (!SIDES.has(target)) return sendJson(res, 400, { ok: false, error: 'bad target' });
      const src = path.join(QUEUE_DIR, target, `${job}.zip`);
      const dstDir = path.join(ARCHIVE_DIR, target);
      await fsp.mkdir(dstDir, { recursive: true });
      const dst = path.join(dstDir, `${Date.now()}-${job}.zip`);
      await fsp.rename(src, dst).catch(async (e) => {
        if (e.code === 'ENOENT') return;
        throw e;
      });
      log('ack', { target, job });
      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'POST' && url.pathname === '/upload') {
      const source = url.searchParams.get('source');
      const target = url.searchParams.get('target');
      const job = safeJob(url.searchParams.get('job'));
      if (!SIDES.has(source) || !SIDES.has(target) || source === target) return sendJson(res, 400, { ok: false, error: 'bad source/target' });
      const len = Number(req.headers['content-length'] || 0);
      if (!len || len > MAX_BYTES) return sendJson(res, 413, { ok: false, error: 'too large', maxBytes: MAX_BYTES });
      const dir = path.join(QUEUE_DIR, target);
      await fsp.mkdir(dir, { recursive: true });
      const tmp = path.join(dir, `${job}.part`);
      const final = path.join(dir, `${job}.zip`);
      let received = 0;
      req.on('data', chunk => {
        received += chunk.length;
        if (received > MAX_BYTES) req.destroy(new Error('too large'));
      });
      await pipeline(req, fs.createWriteStream(tmp));
      await fsp.rename(tmp, final);
      log('upload', { source, target, job, bytes: received });
      return sendJson(res, 200, { ok: true, job, bytes: received });
    }

    sendJson(res, 404, { ok: false, error: 'not found' });
  } catch (error) {
    log('error', { message: error?.message || String(error), stack: error?.stack });
    if (!res.headersSent) sendJson(res, 500, { ok: false, error: error?.message || String(error) });
    else res.destroy(error);
  }
});

server.listen(PORT, '0.0.0.0', () => {
  log('listening', { port: PORT, dataDir: DATA_DIR, appDir: APP_DIR });
});
