import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { ensureExtensionKey } from './ensure-extension-key.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(await fs.readFile(path.join(ROOT, 'package.json'), 'utf8'));
const dist = path.join(ROOT, 'dist');
const stageRoot = path.join(dist, '_cws_stage');
const stage = path.join(stageRoot, `${pkg.name}-cws-draft`);
const outFile = path.join(dist, `${pkg.name}-v${pkg.version}-cws-draft.zip`);

await ensureExtensionKey();
await fs.rm(stageRoot, { recursive: true, force: true });
await fs.mkdir(stage, { recursive: true });

for (const item of ['background.js', 'popup.html', 'popup.css', 'popup.js']) {
  await fs.copyFile(path.join(ROOT, 'extension', item), path.join(stage, item));
}
await fs.cp(path.join(ROOT, 'extension', 'icons'), path.join(stage, 'icons'), { recursive: true });
const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'extension', 'manifest.json'), 'utf8'));
delete manifest.key;
await fs.writeFile(path.join(stage, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', 'utf8');

await fs.mkdir(dist, { recursive: true });
const res = spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(ROOT, 'tools', 'compress-archive.ps1'), stage, outFile], { cwd: ROOT, encoding: 'utf8', windowsHide: true });
if (res.status !== 0) throw new Error((res.stderr || res.stdout || '').trim() || 'CWS archive compression failed');
const st = await fs.stat(outFile);
await fs.rm(stageRoot, { recursive: true, force: true });
console.log(JSON.stringify({ ok: true, package: outFile, bytes: st.size, note: 'CWS draft is extension-only; manifest.key removed for Chrome Web Store upload.' }, null, 2));
