param(
  [Parameter(ValueFromRemainingArguments=$true)][string[]]$Files
)

$ErrorActionPreference = 'Stop'
$failed = @()
foreach ($file in $Files) {
  $tokens = $null
  $errors = $null
  [System.Management.Automation.Language.Parser]::ParseFile($file, [ref]$tokens, [ref]$errors) | Out-Null
  if ($errors -and $errors.Count -gt 0) {
    $failed += [pscustomobject]@{ file = $file; errors = @($errors | ForEach-Object { $_.Message }) }
  }
}
if ($failed.Count -gt 0) {
  $failed | ConvertTo-Json -Depth 5
  exit 1
}
@{ ok = $true; files = $Files.Count } | ConvertTo-Json -Compress
