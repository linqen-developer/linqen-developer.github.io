# PROJECT_CONTRACT.md - Remote File Move

[PRODUCT]
name=Remote File Move
version=0.2.1
primary_user=people moving allowed file types between their own trusted Windows PCs
promise=install the Chrome extension plus the native helper, then move files between trusted PCs with normal Ctrl+C -> Ctrl+V workflow

[CORE_FLOW]
1=User installs Chrome Web Store extension
2=User installs Remote File Move native helper once on each trusted Windows PC
3=Native helper registers `com.openclaw.remote_file_move` and allows the CWS extension ID `bheeeemfbmphehdchegdgneboadjdjcd`
4=Bridge agent watches copied allowed files and sends them through the trusted relay
5=Receiving PC imports payload and sets Windows FileDrop clipboard so Ctrl+V works in Explorer
6=Chrome extension controls status, repair, pause/resume, recent files, and Chrome-download fallback

[ARCHITECTURE]
extension=Chrome MV3 popup/background with nativeMessaging
native_helper=Node native host + PowerShell FileDrop/agent + relay client
relay=trusted bridge endpoint default http://100.82.187.108:18892
cws_item_id=bheeeemfbmphehdchegdgneboadjdjcd
native_host=com.openclaw.remote_file_move
allowed_origins=CWS item ID + local dev extension ID

[NON_GOALS]
do_not=pretend Chrome-only can set Windows FileDrop clipboard
do_not=ship a fake status-only extension as the product
do_not=disturb existing OpenClawClipboardBridge unless explicitly installing/activating this helper

[SAFETY]
allowed_extensions=.png|.jpg|.jpeg|.pdf|.zip
max_bytes=100MB
token_policy=helper uses local token.txt; token not packaged in CWS extension
external_side_effect=publishing/submitting CWS package requires review-state checks

[DELIVERY]
source=C:\Users\Andrea\Desktop\Andrea\dev\remote-file-move
cws_package=dist\remote-file-move-v0.2.1-cws-draft.zip
helper_package=dist\remote-file-move-v0.2.1.zip
