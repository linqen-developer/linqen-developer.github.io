const HOST_NAME = 'com.openclaw.remote_file_move';
const STATUS_ALARM = 'remote-file-move-status';
const AUTO_DOWNLOAD_ALARM = 'remote-file-move-auto-download';

async function nativeCall(action, payload = {}) {
  return new Promise((resolve) => {
    const requestId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    chrome.runtime.sendNativeMessage(HOST_NAME, { requestId, action, payload }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, action, error: chrome.runtime.lastError.message, nativeUnavailable: true });
        return;
      }
      resolve(response || { ok: false, action, error: 'empty native response' });
    });
  });
}

async function setBadgeFromStatus(status) {
  if (!status?.ok) {
    await chrome.action.setBadgeText({ text: '!' });
    await chrome.action.setBadgeBackgroundColor({ color: '#A94747' });
    return;
  }
  const state = status.state || 'unknown';
  if (state === 'ready') {
    await chrome.action.setBadgeText({ text: '' });
    return;
  }
  if (state === 'paused') {
    await chrome.action.setBadgeText({ text: 'Ⅱ' });
    await chrome.action.setBadgeBackgroundColor({ color: '#A86A12' });
    return;
  }
  await chrome.action.setBadgeText({ text: '!' });
  await chrome.action.setBadgeBackgroundColor({ color: '#A94747' });
}

async function refreshStatus() {
  const status = await nativeCall('status');
  await chrome.storage.local.set({ lastStatus: status, lastStatusAt: Date.now() });
  await setBadgeFromStatus(status);
  return status;
}

async function waitForDownload(downloadId) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      chrome.downloads.onChanged.removeListener(listener);
      resolve({ ok: false, error: 'download timeout' });
    }, 180000);

    function listener(delta) {
      if (delta.id !== downloadId) return;
      if (delta.state?.current === 'complete') {
        clearTimeout(timeout);
        chrome.downloads.onChanged.removeListener(listener);
        chrome.downloads.search({ id: downloadId }, (items) => {
          const item = items?.[0];
          resolve(item ? { ok: true, item } : { ok: false, error: 'download item missing' });
        });
      }
      if (delta.state?.current === 'interrupted') {
        clearTimeout(timeout);
        chrome.downloads.onChanged.removeListener(listener);
        resolve({ ok: false, error: 'download interrupted' });
      }
    }
    chrome.downloads.onChanged.addListener(listener);
  });
}

async function downloadPending() {
  const info = await nativeCall('pendingDownloadInfo');
  if (!info.ok || !info.pending) return info;

  const headers = [];
  if (info.token) headers.push({ name: 'X-Bridge-Token', value: info.token });

  return new Promise((resolve) => {
    chrome.downloads.download({
      url: info.url,
      filename: `Remote File Move/${info.job}.zip`,
      conflictAction: 'uniquify',
      saveAs: false,
      headers
    }, async (downloadId) => {
      if (chrome.runtime.lastError || !downloadId) {
        resolve({ ok: false, action: 'downloadPending', error: chrome.runtime.lastError?.message || 'download failed' });
        return;
      }
      const completed = await waitForDownload(downloadId);
      if (!completed.ok) {
        resolve({ ...completed, action: 'downloadPending' });
        return;
      }
      const imported = await nativeCall('importArchive', {
        archivePath: completed.item.filename,
        job: info.job,
        source: info.source || null
      });
      if (imported.ok) {
        await chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: 'Remote File Move',
          message: `${imported.files || 0}개 파일을 클립보드에 준비했습니다.`
        }).catch(() => {});
      }
      await refreshStatus();
      resolve({ ...imported, downloadId, archivePath: completed.item.filename });
    });
  });
}

async function handleMessage(message) {
  const action = message?.action;
  const payload = message?.payload || {};
  if (action === 'status') return refreshStatus();
  if (action === 'downloadPending') return downloadPending();
  if (['ensureStarted', 'pause', 'resume', 'openReceived', 'copyLastReceived', 'diagnose', 'logs'].includes(action)) {
    const result = await nativeCall(action, payload);
    await refreshStatus();
    return result;
  }
  return { ok: false, error: `unknown action: ${action}` };
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.alarms.create(STATUS_ALARM, { periodInMinutes: 1 });
  await refreshStatus();
});

chrome.runtime.onStartup.addListener(async () => {
  await chrome.alarms.create(STATUS_ALARM, { periodInMinutes: 1 });
  await refreshStatus();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === STATUS_ALARM) await refreshStatus();
  if (alarm.name === AUTO_DOWNLOAD_ALARM) {
    const { autoDownload } = await chrome.storage.local.get('autoDownload');
    if (autoDownload) await downloadPending();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then(sendResponse).catch((error) => {
    sendResponse({ ok: false, error: error?.message || String(error) });
  });
  return true;
});
