const $ = (id) => document.getElementById(id);

const statePill = $('statePill');
const stateText = $('stateText');
const sideText = $('sideText');
const peerText = $('peerText');
const detailText = $('detailText');
const activityList = $('activityList');
const allowedText = $('allowedText');

const buttons = {
  repair: $('repairBtn'),
  download: $('downloadBtn'),
  pause: $('pauseBtn'),
  resume: $('resumeBtn'),
  copyLast: $('copyLastBtn'),
  openReceived: $('openReceivedBtn'),
  refresh: $('refreshBtn'),
  diagnose: $('diagnoseBtn'),
  installGuide: $('installGuideBtn')
};

function send(action, payload = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action, payload }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response || { ok: false, error: 'empty response' });
    });
  });
}

function setBusy(isBusy) {
  Object.values(buttons).forEach((button) => {
    if (button) button.disabled = isBusy;
  });
}

function setState(status) {
  statePill.className = 'state-pill';
  if (!status?.ok) {
    statePill.classList.add('state-error');
    stateText.textContent = '연결 필요';
    detailText.textContent = status?.nativeUnavailable
      ? 'Native helper가 필요합니다. Helper 설치 안내를 열어 각 PC에 helper를 설치해 주세요.'
      : (status?.error || 'Native helper 연결이 필요합니다.');
    sideText.textContent = '-';
    peerText.textContent = '-';
    return;
  }

  const state = status.state || 'unknown';
  const label = state === 'ready' ? '준비됨' : state === 'paused' ? '일시정지' : '확인 필요';
  statePill.classList.add(state === 'ready' ? 'state-ready' : state === 'paused' ? 'state-paused' : 'state-error');
  stateText.textContent = label;
  sideText.textContent = status.side || '-';
  peerText.textContent = status.peer || '-';

  const queue = Number(status.pendingCount || 0);
  const relay = status.relayOk ? 'relay 정상' : 'relay 확인 필요';
  const token = status.hasToken ? 'token 있음' : 'token 없음';
  detailText.textContent = state === 'ready'
    ? `${relay} · 대기 파일 ${queue}개 · ${token}`
    : `${relay} · ${status.reason || '복구 버튼으로 다시 시작할 수 있습니다.'}`;

  if (status.maxBytesMb) allowedText.textContent = `${(status.allowedExtensions || []).join(' · ')} / ${status.maxBytesMb}MB`;
}

function formatTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return String(ts);
  return d.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
}

function renderActivity(status) {
  const rows = status?.recent || [];
  if (!rows.length) {
    activityList.innerHTML = '<div class="empty-row">아직 표시할 활동이 없습니다.</div>';
    return;
  }
  activityList.textContent = '';
  for (const row of rows.slice(0, 5)) {
    const el = document.createElement('div');
    el.className = 'activity-row';
    const title = document.createElement('strong');
    title.textContent = eventLabel(row.event);
    const meta = document.createElement('span');
    meta.textContent = `${formatTime(row.ts)} · ${row.files ? `${row.files}개 파일` : row.job || row.error || ''}`.trim();
    el.append(title, meta);
    activityList.appendChild(el);
  }
}

function eventLabel(event) {
  const map = {
    started: '브릿지 시작',
    sent: '전송 완료',
    received: '수신 완료',
    clipboard_set: '클립보드 준비',
    receive_error: '수신 오류',
    send_error: '전송 오류',
    paused: '일시정지',
    resumed: '재개',
    imported_archive: 'Chrome 다운로드 수신'
  };
  return map[event] || event || '활동';
}

async function refresh() {
  const status = await send('status');
  setState(status);
  renderActivity(status);
  return status;
}

async function run(action, payload = {}) {
  setBusy(true);
  try {
    const result = await send(action, payload);
    await refresh();
    if (!result.ok && result.error) detailText.textContent = result.error;
    if (result.ok && action === 'downloadPending' && result.pending === false) detailText.textContent = '현재 받을 파일이 없습니다.';
    return result;
  } finally {
    setBusy(false);
  }
}

buttons.repair.addEventListener('click', () => run('ensureStarted'));
buttons.download.addEventListener('click', () => run('downloadPending'));
buttons.pause.addEventListener('click', () => run('pause'));
buttons.resume.addEventListener('click', () => run('resume'));
buttons.copyLast.addEventListener('click', () => run('copyLastReceived'));
buttons.openReceived.addEventListener('click', () => run('openReceived'));
buttons.refresh.addEventListener('click', refresh);
buttons.diagnose.addEventListener('click', async () => {
  const result = await run('diagnose');
  if (result.ok) detailText.textContent = result.summary || '진단 완료';
});
buttons.installGuide.addEventListener('click', () => {
  window.open('https://linqen-developer.github.io/remote-file-move/', '_blank', 'noopener,noreferrer');
});

refresh();
